import { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';

export default function Chat() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [userId, setUserId] = useState('');
  const [isWaiting, setIsWaiting] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const chatEndRef = useRef(null);

  // Sample welcome messages
  const welcomeMessages = [
    "Hi there! How can I help you today?",
    "Hello! What would you like to know?",
    "Welcome! Ask me anything you'd like."
  ];

  useEffect(() => {
    let storedId = localStorage.getItem('chat_user_id');
    if (!storedId) {
      storedId = uuidv4();
      localStorage.setItem('chat_user_id', storedId);
      
      // Add welcome message for new users
      setTimeout(() => {
        const welcomeMessage = {
          role: 'bot',
          content: welcomeMessages[Math.floor(Math.random() * welcomeMessages.length)]
        };
        setMessages(prev => [welcomeMessage]);
      }, 500);
    }
    setUserId(storedId);
    
    // Simulate online status changes
    const interval = setInterval(() => {
      setIsOnline(Math.random() > 0.1);
    }, 30000);
    
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isWaiting) return;

    const userMessage = { role: 'user', content: input, timestamp: new Date() };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsWaiting(true);

    try {
      // Simulate typing indicator
      await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));
      
      const res = await axios.post('http://127.0.0.1:8000/chat', {
        user_id: userId,
        message: input,
      });

      const botMessage = { 
        role: 'bot', 
        content: res.data.response,
        timestamp: new Date()
      };
      setMessages((prev) => [...prev, botMessage]);
    } catch (err) {
      console.error('API error:', err);
      setMessages((prev) => [
        ...prev,
        { 
          role: 'bot', 
          content: 'Something went wrong. Please try again.',
          timestamp: new Date()
        },
      ]);
    } finally {
      setIsWaiting(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-md h-[80vh] bg-white shadow-xl rounded-2xl flex flex-col overflow-hidden border border-gray-100 transform transition-all hover:shadow-2xl">
        {/* Chat header */}
        <div className="bg-gradient-to-r from-purple-500 to-indigo-500 p-4 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`h-3 w-3 rounded-full ${isOnline ? 'bg-green-300' : 'bg-gray-300'}`}></div>
            <h2 className="font-bold text-lg">AI Assistant</h2>
          </div>
          <div className="text-sm opacity-80">
            {isOnline ? 'Online' : 'Offline'}
          </div>
        </div>
        
        {/* Chat messages */}
        <div className="flex-1 p-4 overflow-y-auto custom-scrollbar space-y-4 bg-gradient-to-b from-white to-indigo-50">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-gray-400">
              <div className="mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </div>
              <p className="text-center">Send a message to start chatting</p>
            </div>
          )}
          
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} group`}
            >
              <div className={`max-w-[80%] flex ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'} items-end space-x-2`}>
                <div
                  className={`px-4 py-3 rounded-2xl text-sm whitespace-pre-wrap relative transition-all duration-200 ${
                    msg.role === 'user'
                      ? 'bg-indigo-500 text-white rounded-tr-none'
                      : 'bg-white text-gray-800 shadow-sm rounded-tl-none border border-gray-100'
                  }`}
                >
                  {msg.content}
                  <span className={`absolute -bottom-5 text-xs text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity ${
                    msg.role === 'user' ? 'right-2' : 'left-2'
                  }`}>
                    {formatTime(new Date(msg.timestamp))}
                  </span>
                </div>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                  msg.role === 'user' 
                    ? 'bg-indigo-100 text-indigo-600' 
                    : 'bg-purple-100 text-purple-600'
                }`}>
                  {msg.role === 'user' ? 'You' : 'AI'}
                </div>
              </div>
            </div>
          ))}
          
          {isWaiting && (
            <div className="flex justify-start">
              <div className="max-w-[80%] flex flex-row items-end space-x-2">
                <div className="px-4 py-3 rounded-2xl bg-white text-gray-800 shadow-sm rounded-tl-none border border-gray-100 flex space-x-1">
                  <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
                <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-xs font-bold">
                  AI
                </div>
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Input area */}
        <div className="p-4 border-t border-gray-100 bg-white">
          <div className="relative flex items-center">
            <textarea
              rows="1"
              className="flex-1 border border-gray-200 rounded-full px-4 py-3 pr-12 focus:outline-none focus:ring-2 focus:ring-purple-300 resize-none transition-all"
              placeholder="Type a message..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              disabled={isWaiting}
              style={{ minHeight: '44px', maxHeight: '120px' }}
            />
            <button
              onClick={handleSend}
              disabled={isWaiting || !input.trim()}
              className={`absolute right-2 w-10 h-10 rounded-full flex items-center justify-center transition ${
                isWaiting || !input.trim()
                  ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-purple-500 to-indigo-500 text-white hover:from-purple-600 hover:to-indigo-600 shadow-md'
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
          <div className="text-xs text-gray-400 mt-2 text-center">
            {isOnline ? 'Typically replies instantly' : 'Offline - responses may be delayed'}
          </div>
        </div>
      </div>
    </div>
  );
}