/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      colors: {
        'chat-bg': '#1e1e2f',
        'chat-input': '#2a2a3d',
        'chat-user': '#6b21a8',
        'chat-bot': '#2a2a3d',
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'), // Optional: for better form/input styling
  ],
};
